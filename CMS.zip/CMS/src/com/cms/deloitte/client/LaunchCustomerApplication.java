package com.cms.deloitte.client;

import java.util.Scanner;

import com.cms.deloitte.dao.impl.CustomerDAOImpl;
import com.cms.deloitte.model.Customer;

public class LaunchCustomerApplication {
	public static void runCustomerApp() {
		System.out.println("##### Welcome to Customer Application! #####");
		System.out.println("##### 1.Add New Customer #####");
		System.out.println("##### 2.Update Existing Customer #####");
		System.out.println("##### Welcome to Customer Application! #####");
		System.out.println("##### Welcome to Customer Application! #####");
		System.out.println("##### 6.Exit Application #####");
		System.out.println("Enter your choice (1-6): ");

		Scanner scanner = new Scanner(System.in);
		int choice = scanner.nextInt();
		switch (choice) {
		case 1:
			Customer customer = new Customer();
			customer.acceptCustomerDetails();
			CustomerDAOImpl impl = new CustomerDAOImpl();
			boolean result = impl.addCustomer(customer);
			System.out.println(result);
		case 6:
			System.out.println("Thank you for visitng!");
			System.exit(0);
			break;
		default:
			System.out.println("Invalid choice. Please try again.");
		}
		scanner.close();
	}
}
