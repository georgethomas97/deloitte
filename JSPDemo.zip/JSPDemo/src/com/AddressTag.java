package com;
import java.io.IOException;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.TagSupport;

public class AddressTag extends TagSupport {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	public int doStartTag() throws JspException {
		JspWriter out = pageContext.getOut();
		
		try {
			out.println("Deloitte<br/>");
			out.println("Block C<br/>Divyasree Technopolis<br/>");
			out.println("Survey No: 123 & 132/2");
			out.println("Yemlur Post");
			out.println("Off Old Airport Road");
			out.println("Karnataka 560037<br/>");
		} catch (IOException e) {
			e.printStackTrace();
		}
		return super.doStartTag();
		
	}
	
}
