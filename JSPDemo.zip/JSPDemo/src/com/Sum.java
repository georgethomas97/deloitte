package com;

public class Sum {
 public int addNumbers(int a, int b) {
	 return a+b;
 }
}
