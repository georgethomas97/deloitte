package com.examapp.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class EntryController
 */
public class EntryController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EntryController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String username = request.getParameter("username");
		PrintWriter out = response.getWriter();
		out.println("<h1>Instructions</h1>");
		out.println("<ul><li>Instruction1</li><li>Instruction2</li><li>Instruction3</li>");
		HttpSession session = request.getSession();
		session.setAttribute("username", username);
		
		out.println("<form action = 'question1.jsp'><input type = 'submit' value = 'Start'></form>");
	}

}
