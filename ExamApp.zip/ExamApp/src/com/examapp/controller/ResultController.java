package com.examapp.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class ResultController
 */
public class ResultController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ResultController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session = request.getSession();
		String q1 = (String)session.getAttribute("q1");
		String q2 = (String)session.getAttribute("q2");
		String q3 = request.getParameter("q3");
		session.setAttribute("q3", q3);
		
		int score1 = 0;
		int score2 = 0;
		int score3 = 0;
		if (q1.equals("a")) {
			score1 = 10;
		}
		if (q2.equals("b")) {
			score2 = 10;
		}
		if (q3.equals("c")) {
			score3 = 10;
		}
		session.setAttribute("score1", score1);
		session.setAttribute("score2", score2);
		session.setAttribute("score3", score3);
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("result.jsp");
		dispatcher.forward(request, response);
	}

}
