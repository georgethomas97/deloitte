package calculator;

public class Division extends Arithmetic {

	@Override
	public int calculate() {
		setNum3(getNum1()/getNum2());
		return getNum3();
	}

}
