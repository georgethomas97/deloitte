package calculator;

import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Arithmetic[] arithmetic = {new Addition(), new Subtraction(), new Multiplication(), new Division()};
		Scanner scanner = new Scanner(System.in);
		System.out.println("Please enter your choice: \n1.Add\n2.Subtract\n3.Multiply\n4.Divide");
		int choice = scanner.nextInt();
		System.out.println("Please enter first number");
		int num1 = scanner.nextInt();
		System.out.println("Please enter second number");
		int num2 = scanner.nextInt();
		arithmetic[choice-1].setNum1(num1);
		arithmetic[choice-1].setNum2(num2);
		int result = arithmetic[choice-1].calculate();
		scanner.close();
		System.out.println("Result is: "+ result);
		
	}
}
