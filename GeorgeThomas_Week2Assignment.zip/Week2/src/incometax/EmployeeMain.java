package incometax;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class EmployeeMain {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter no: of employees - ");
		int count = scanner.nextInt();
		EmployeeVo[] employeeArray = new EmployeeVo[count];
		EmployeeBo bo;

		for (int i = 0; i < employeeArray.length; i++) {
			System.out.println("Enter Emp details [ID NAME INCOME]");
			employeeArray[i] = new EmployeeVo(scanner.nextInt(), scanner.next(), scanner.nextInt(), 0);
			bo = new EmployeeBo();
			bo.calIncomeTax(employeeArray[i]);
		}
		System.out.println("Employee Details: ");
		System.out.println("");
		for (int i = 0; i < count; i++) {
			System.out.println(employeeArray[i]);
		}
		System.out.println("");

		List<EmployeeVo> employeeList = Arrays.asList(employeeArray);
		Collections.sort(employeeList, new EmployeeSort());

		System.out.println("Sorted Employee Details: ");
		System.out.println("");
		System.out.println(employeeList);
		scanner.close();

	}
}
