package incometax;

public class EmployeeBo {
	public void calIncomeTax(EmployeeVo employee) {
		int annualincome = employee.getAnnualincome();
		int incometax = annualincome*10/100;
		employee.setIncometax(incometax);
	}
}
