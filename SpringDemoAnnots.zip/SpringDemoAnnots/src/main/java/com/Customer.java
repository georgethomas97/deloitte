package com;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;

import java.io.Serializable;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

public class Customer implements Serializable, InitializingBean, DisposableBean {
	private int customerId;
	private String customerName;
	private String customerAddress;
	private int billAmount;
	
	@Autowired
	private ContactDetails customerContact;

	public Customer(int customerId, String customerName, String customerAddress, int billAmount,
			ContactDetails customerContact) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.customerAddress = customerAddress;
		this.billAmount = billAmount;
		this.customerContact = customerContact;
	}

	public ContactDetails getCustomerContact() {
		return customerContact;
	}

	public void setCustomerContact(ContactDetails customerContact) {
		this.customerContact = customerContact;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getCustomerAddress() {
		return customerAddress;
	}

	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}

	public int getBillAmount() {
		return billAmount;
	}

	public void setBillAmount(int billAmount) {
		this.billAmount = billAmount;
	}

	public Customer() {
		super();
		System.out.println("Constructor");
	}

	public Customer(int customerId, String customerName, String customerAddress, int billAmount) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.customerAddress = customerAddress;
		this.billAmount = billAmount;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", customerName=" + customerName + ", customerAddress="
				+ customerAddress + ", billAmount=" + billAmount + ", customerContact=" + customerContact + "]";
	}
	@PostConstruct
	public void dd1() {
		System.out.println("Hello");
	}
	@PreDestroy
	public void dd2() {
		System.out.println("Bye");
	}

	public void destroy() throws Exception {
		System.out.println("Destroyed");
		
	}

	public void afterPropertiesSet() throws Exception {
		System.out.println("Begun");
		
	}
	

	
}
