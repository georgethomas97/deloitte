package com;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.config.AppConfig;

public class AppSpring {
	public static void main(String[] args) {
		
//		ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
		AbstractApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
		Customer customer1 = context.getBean(Customer.class);
		customer1.setCustomerId(1001);
		customer1.setCustomerName("Babu");
		customer1.setCustomerAddress("Bihar");
		customer1.setBillAmount(3000);
//		Customer customer2 = context.getBean(Customer.class);
//		Customer customer3 = context.getBean(Customer.class);
//		customer.setCustomerContact(new ContactDetails("1234567890", "babunamboodidi@gmail.com"));

		ContactDetails contactDetails = context.getBean(ContactDetails.class);
		contactDetails.setMobileNumber("9014502350");
		contactDetails.setEmailId("babunamboodidi@gmail.com");
				
		System.out.println(customer1);
//		System.out.println(customer2);		
//		System.out.println(customer3);		


//		Resource resource = new ClassPathResource("beans.xml");
//		BeanFactory factory = new XmlBeanFactory(resource);
//		Customer customer = (Customer)factory.getBean("cust2");
////		customer.setCustomerName("Sabu");
//		System.out.println(customer);
		
		context.registerShutdownHook();
	}
}
