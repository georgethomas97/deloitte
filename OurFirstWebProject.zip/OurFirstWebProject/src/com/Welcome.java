package com;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Welcome
 */
public class Welcome extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Welcome() {
        super();
        // TODO Auto-generated constructor stub
    }
    int counter = 0;
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	counter++;
		String user = request.getParameter("username");
		String pass = request.getParameter("password");
		response.getWriter().println("<body bgcolor = 'blue'><h1>Welcome to my website, " + user + "</h1>");
		response.getWriter().println("<h2>Your password: " + pass + "</h1>");
		response.getWriter().println("<h3>You are visitor no:" + counter);
		response.getWriter().println("<br/> <a href = 'Shop.html'>Shop</a>");
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	counter++;
		String user = request.getParameter("username");
		String pass = request.getParameter("password");
		response.getWriter().println("<body bgcolor = 'orange'><h1>Welcome to my website, " + user + "</h1>");
		response.getWriter().println("<h2>Your password: " + pass + "</h1>");
		response.getWriter().println("<h3>You are visitor no:" + counter);
		response.getWriter().println("<br/> <a href = 'Shop.html'>Shop</a>");
    }
	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		counter++;
		String user = request.getParameter("username");
		String pass = request.getParameter("password");
		response.setContentType("text/html");
		response.getWriter().println("<body bgcolor = 'green'><h1>Welcome to my website, " + user + "</h1>");
		response.getWriter().println("<h2>Your password: " + pass + "</h1>");
		response.getWriter().println("<h3>You are visitor no:" + counter);
		response.getWriter().println("<br/> <a href = 'Shop.html'>Shop</a>");
	}

}
