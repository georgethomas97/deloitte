package com;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cms.deloitte.dao.CustomerDAO;
import com.cms.deloitte.dao.impl.CustomerDAOImpl;
import com.cms.deloitte.model.Customer;

/**
 * Servlet implementation class CustServlet
 */
public class CustServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public CustServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		int customerId = Integer.parseInt(request.getParameter("id"));
		String customerName = request.getParameter("name");
		String customerAddress = request.getParameter("address");
		int billAmount = Integer.parseInt(request.getParameter("amount"));

		response.getWriter().println("<h3>Customer ID: " + customerId + "</h3>");
		response.getWriter().println("<h3>Customer Name: " + customerName + "</h3>");
		response.getWriter().println("<h1>Customer Address: " + customerAddress + "</h1>");
		response.getWriter().println("<h1>Bill Amount: " + billAmount + "</h1>");

		Customer customer = new Customer(customerId, customerName, customerAddress, billAmount);
		CustomerDAO customerDAO = new CustomerDAOImpl();

		if (customerDAO.isCustomerExists(customerId)) {
			response.getWriter().println(customerId + "already exists.");
		} else {
			customerDAO.addCustomer(customer);
			response.getWriter().println(customerId + "details already exists");
		}

	}

}
