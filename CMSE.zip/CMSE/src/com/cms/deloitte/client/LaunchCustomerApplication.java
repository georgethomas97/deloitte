package com.cms.deloitte.client;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.cms.deloitte.dao.CustomerDAO;
import com.cms.deloitte.dao.impl.CustomerDAOImpl;
import com.cms.deloitte.model.Customer;

public class LaunchCustomerApplication {
	public static void runCustomerApp() {
		
			Scanner scanner = new Scanner(System.in);
			System.out.println("##### Welcome to Customer Application! #####");
			System.out.println("##### 1.Add New Customer #####");
			System.out.println("##### 2.Update Existing Customer #####");
			System.out.println("##### 3.Delete Customer Details #####");
			System.out.println("##### 4.Find a Customer #####");
			System.out.println("##### 5.List all Customers #####");
			System.out.println("##### 6.Exit Application #####");
			System.out.println("");
			System.out.println("Enter your choice (1-6): ");

			
			int choice = scanner.nextInt();
			switch (choice) {
			case 1:
				Customer customer = new Customer();
				customer.acceptCustomerDetails();
				CustomerDAO customerDAO = new CustomerDAOImpl();
				if (!customerDAO.isCustomerExists(customer.getCustomerId())) {
					boolean result = customerDAO.addCustomer(customer);
					if (result) {
						System.out.println(customer.getCustomerId() + " details entered successfully.");
					}
				} else {
					System.out.println(customer.getCustomerId() + " already exists.");
				}
				break;
			case 2:
				customer = new Customer();
				customer.acceptCustomerDetails();
				customerDAO = new CustomerDAOImpl();
				if (customerDAO.isCustomerExists(customer.getCustomerId())) {
					boolean result = customerDAO.updateCustomer(customer);
					if (result) {
						System.out.println(customer.getCustomerId() + " details updated successfully.");
					}
				} else {
					System.out.println(customer.getCustomerId() + " does not exist.");
				}
				break;
			case 3:
				System.out.println("Enter customer ID: ");
				int customerId = scanner.nextInt();
				customerDAO = new CustomerDAOImpl();
				if (customerDAO.isCustomerExists(customerId)) {
					boolean result = customerDAO.deleteCustomer(customerId);
					if (result) {
						System.out.println(customerId + " details deleted successfully.");
					}
				} else {
					System.out.println(customerId + " does not exist.");
				}
				break;
			case 4:
				customer = new Customer();
				System.out.println("Enter customer ID: ");
				customerId = scanner.nextInt();
				customerDAO = new CustomerDAOImpl();
				if (customerDAO.isCustomerExists(customerId)) {
					customer = customerDAO.findCustomer(customerId);
					System.out.println(customer);
				} else {
					System.out.println(customerId + " does not exist.");
				}
				break;
			case 5:
				List<Customer> allCustomers = new ArrayList<Customer>();
				customerDAO = new CustomerDAOImpl();
				allCustomers = customerDAO.listCustomers();
				System.out.println(allCustomers);
				break;
			case 6:
				System.out.println("Thank you for visitng!");
				System.exit(0);
				break;
			default:
				System.out.println("Invalid choice. Please try again.");
			}
		}

	}
