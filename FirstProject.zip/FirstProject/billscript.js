cardNo = prompt("Enter your card number: ", "1234567890123456");
billAmount = prompt("Enter Bill amount: ", "0");
today = new Date();
date1 = today.getDate();
getBill(date1);
function getBill(data) {

	if (data > 15) {
		bill = parseInt(billAmount) + parseInt(50 * (data - 15));
		alert("Your bill amount is: " + bill);
	} else {
		alert("Your bill amount is: " + billAmount);
	}
}