package demoExceptions;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class CustomerMain {
	public static void main(String[] args) {
		List<Customer> cust = new ArrayList<>();

		Customer cust1 = new Customer(101, "Jaya", "Delhi", 98000);
		cust.add(cust1);
		cust.add(new Customer(102, "Hari", "Delhi", 65000));
		cust.add(new Customer(103, "Tarun", "Mumbai", 123000));
		cust.add(new Customer(104, "Javed", "Jharkand", 50000));
		cust.add(new Customer(105, "Ameen", "Kochi", 74999));

		Iterator<Customer> i = cust.iterator();

		while (i.hasNext()) {
			System.out.println(i.next());
		}

		System.out
				.println("Enter parameter for sorting: \n 1.Name \n 2.Address \n 3.Bill Amount");
		Scanner sc = new Scanner(System.in);
		int choice = sc.nextInt();
		sc.close();
		if (choice == 1) {
			Collections.sort(cust, new NameComp());
			System.out.println();
			System.out.println("List sorted on names:\n");
			System.out.println();
		} else if (choice == 2) {
			Collections.sort(cust, new Comparator<Customer>() {

				@Override
				public int compare(Customer o1, Customer o2) {
					if (o1.getCustomerAddress().compareTo(
							o2.getCustomerAddress()) > 0)
						return 0;
					else
						return -1;
				}
			});
		}

		else if (choice == 3) {
			Collections.sort(cust);
			System.out.println();
			System.out.println("After sorting on Bill Amount:\n");
			System.out.println();
		}

		Iterator<Customer> j = cust.iterator();

		while (j.hasNext()) {
			System.out.println(j.next());
		}

	}
}
