package demoExceptions;

import java.util.Scanner;

class InvalidAgeException extends Exception {
	public InvalidAgeException() {

	}
	public InvalidAgeException(String msg) {
		super(msg);
	}
}

class NewYearParty {
	int eligibleage = 16;
	Scanner sc = new Scanner(System.in);
	int age;
	public void enterClub() throws InvalidAgeException {
		System.out.println("Enter your Age:");
		age = sc.nextInt();
		if (age<eligibleage) {
			throw new InvalidAgeException("Under age");
		}
		else {
			System.out.println("You may come in.");	
		}
	}
}

public class Demo3 {
	public static void main(String[] args) {
		NewYearParty ny = new NewYearParty();
		try {
			ny.enterClub();
		} catch (InvalidAgeException e) {
			System.out.println("You are under age.");
		}
	}
}
