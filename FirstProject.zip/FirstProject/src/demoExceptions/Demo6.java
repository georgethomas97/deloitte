package demoExceptions;

import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;

public class Demo6 {
	public static void main(String[] args) {
		Set<String> names = new LinkedHashSet<String>();
		names.add("Sachin");
		names.add("Nibras");
		names.add("Abraham");
		names.add("George");

		System.out.println(names);
		names.add("Merin");
		System.out.println(names);
		
		Iterator<String> i = names.iterator();
		
		while (i.hasNext()) {
			String str = i.next();
			if (str.equals("George")) {
				continue;
			}
			System.out.println(str);
		}
	}
}
