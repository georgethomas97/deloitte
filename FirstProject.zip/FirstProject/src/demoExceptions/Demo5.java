package demoExceptions;

import java.util.HashSet;
import java.util.Set;

public class Demo5 {
	@SuppressWarnings("unchecked")
	public static void main(String[] args) {
		@SuppressWarnings("rawtypes")
		Set names = new HashSet<>();
		names.add("Sachin");
		names.add("Nibras");
		names.add("Abraham");
		names.add("George");

		System.out.println(names);
		names.add("Merin");
		System.out.println(names);
		names.remove("Merin");
		System.out.println(names);
		System.out.println(names.isEmpty());
		System.out.println(names.size());

	}
}
