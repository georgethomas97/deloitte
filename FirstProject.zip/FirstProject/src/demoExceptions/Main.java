package demoExceptions;

public class Main {
	public static void main(String[] args) {
		Products prod1 = new Products(9651,"Laptop",75,97000);
		System.out.println(prod1);
		Products prod2 = new Products(1001,"Headphones",50,9000);
		System.out.println(prod2);
		Products prod3 = new Products(2546, "TV", 23,45000);
		System.out.println(prod3);
		prod3.setPrice(20000);
		System.out.println(prod3);
	}
}
