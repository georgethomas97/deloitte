package demoExceptions;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class HashMapDemo {
	public static void main(String[] args) {
		HashMap<String,Double> hm = new HashMap<String,Double>();
		
		hm.put("John Jacobs", new Double(34.24));
		hm.put("Kelly Kendall", new Double(324.45));
		hm.put("Gavin Green", new Double(08.76));
		hm.put("Donald Dunce", new Double(345.8));
		hm.put("Mathew Maine", new Double(3438.09));
		
		Set set = hm.entrySet();
		
		Iterator i = set.iterator();
		
		while(i.hasNext()) {
			Map.Entry me = (Map.Entry) i.next();
			System.out.println(me.getKey() + ": ");
			System.out.println(me.getValue());
		}
		System.out.println();
		double balance = ((Double)hm.get("John Jacobs").doubleValue());
		hm.put("John Jacobs", new Double(balance + 1000));
		
		Iterator j = set.iterator();
		
		while(j.hasNext()) {
			Map.Entry me = (Map.Entry) j.next();
			System.out.println(me.getKey() + ": ");
			System.out.println(me.getValue());
		}
	}
	
}
