package demoExceptions;

import java.util.ArrayList;
import java.util.List;

public class Demo4 {
	public static void main(String[] args) {
		List<String> names = new ArrayList<String>();
		names.add("Sachin");
		names.add("Nibras");
		names.add("Abraham");
		names.add("George");

		System.out.println(names);
		names.add(2, "Merin");
		System.out.println(names);
		names.remove(0);
		System.out.println(names);
		System.out.println(names.isEmpty());
		System.out.println(names.get(2));
		System.out.println(names.size());

	}
}
