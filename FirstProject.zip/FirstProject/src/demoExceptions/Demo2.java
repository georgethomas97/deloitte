package demoExceptions;

public class Demo2 {
	public void display1() throws InterruptedException{
		System.out.println("Display 1");
		Thread.sleep(2000);
		System.out.println("Bye!");
	}
	public void display2() throws InterruptedException{
		System.out.println("Display 2");
		Thread.sleep(2000);
		System.out.println("Bye!");
	}
	public static void main(String[] args) throws InterruptedException {
		System.out.println("Main");
		Demo2 d = new Demo2();
		d.display1();
		d.display2();
		System.out.println("End");
	}
}
