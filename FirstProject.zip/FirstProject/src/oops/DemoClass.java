package oops;

import java.util.InputMismatchException;
import java.util.Scanner;

class DemoClass {
	int num1,num2,res;
	Scanner sc = new Scanner(System.in);
	public void display() {
		System.out.println("Welcome to Display");
		try {
			System.out.println("Enter a  number: ");
			num1 = sc.nextInt();
			System.out.println("Enter the next number");
			num2 = sc.nextInt();
			res = num1/num2;
			System.out.println(res);
		}
		catch (InputMismatchException e) {
			System.out.println("Please enter a number.");
		}
		catch (ArithmeticException e) {
			System.out.println("Cannot divide by zero.");
		}
	}
	public static void main() {
		DemoClass d = new DemoClass();
		d.display();
	}
}
