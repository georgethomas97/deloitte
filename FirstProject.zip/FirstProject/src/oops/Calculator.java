package oops;

public class Calculator {
	public void add(int x, int y) {
		System.out.println("Sum1: " + (x+y));
	}
	
	public void add(double x, double y) {
		System.out.println("Sum2: " + (x+y));
	}
	
	public void add(int x, double y) {
		System.out.println("Sum3: " + (x+y));
	}
	
	public void add(double x, int y) {
		System.out.println("Sum4: " + (x+y));
	}
	
	public void diff(int x, int y) {
		System.out.println("Diff1: " + (x-y));
	}
	
	public void diff(double x, double y) {
		System.out.println("Diff2: " + (x-y));
	}
	
	public void diff(int x, double y) {
		System.out.println("Diff3: " + (x-y));
	}
	
	public void diff(double x, int y) {
		System.out.println("Diff4: " + (x-y));
	}
	
	public void mul(int x, int y) {
		System.out.println("Prod1: " + (x*y));
	}
	
	public void mul(double x, double y) {
		System.out.println("Prod2: " + (x*y));
	}
	
	public void mul(int x, double y) {
		System.out.println("Prod3: " + (x*y));
	}
	
	public void mul(double x, int y) {
		System.out.println("Prod4: " + (x*y));
	}
	public void div(int x, int y) {
		System.out.println("Quo1: " + (x/y));
	}
	
	public void div(double x, double y) {
		System.out.println("Quo2: " + (x/y));
	}
	
	public void div(int x, double y) {
		System.out.println("Quo3: " + (x/y));
	}
	
	public void div(double x, int y) {
		System.out.println("Quo4: " + (x/y));
	}
	
	public static void main(String[] args) {
		Calculator c = new Calculator();
		c.add(2, 3);
		c.add(2.1, 3.1);
		c.add(2, 3.1);
		c.add(3.1, 2);
		c.diff(2, 3);
		c.diff(2.1, 3.1);
		c.diff(2, 3.1);
		c.diff(3.1, 2);
		c.mul(2, 3);
		c.mul(2.1, 3.1);
		c.mul(2, 3.1);
		c.mul(3.1, 2);
		c.div(2, 3);
		c.div(2.1, 3.1);
		c.div(2, 3.1);
		c.div(3.1, 2);
	}
}
