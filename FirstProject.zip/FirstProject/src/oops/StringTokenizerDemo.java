package oops;

import java.util.StringTokenizer;

public class StringTokenizerDemo {
	public static void main(String[] args) {
		String text = "The quick brown fox jumps over the lazy dog";
		StringTokenizer st = new StringTokenizer(text);
		System.out.println(st.countTokens());
		while(st.hasMoreElements()) {
			System.out.println(st.nextElement());
		}
	}
}
