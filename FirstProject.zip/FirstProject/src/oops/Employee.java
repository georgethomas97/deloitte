package oops;
import java.util.Scanner;
public class Employee {
	public int employeeId;
	public String employeeName;
	public String employeeAddress;
	public int salary;
	
	public void setDetails() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Employee ID:");
		employeeId = sc.nextInt();
		System.out.println("Enter Employee name:");
		employeeName = sc.next();
		System.out.println("Enter Employee Address:");
		employeeAddress = sc.next();
		System.out.println("Enter Salary:");
		salary = sc.nextInt();
		sc.close();
	}
	public void printDetails() {
		System.out.println("Employee ID : " + employeeId);
		System.out.println("Employee Name : " + employeeName);
		System.out.println("Employee Address : " + employeeAddress);
		System.out.println("Employee Salary : " + salary);
	}
}
