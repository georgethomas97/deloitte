package oops;

public class QuickBrownFox {
	public static void main(String[] args) {
		String qb = "The quick brown fox jumps over the lazy dog";
		System.out.println(qb.charAt(12));
		System.out.println("The string contains is: " + qb.contains("is"));
		System.out.println(qb.concat(" and killed it."));
		System.out.println("The string ends with dogs: " + qb.endsWith("dogs"));
		System.out.println("The string is equal to given string 1: " + qb.equals("The quick brown Fox jumps over the lazy Dog"));
		System.out.println("Thestring is equal to given string 2: " + qb.equals("THE QUICK BROWN FOX JUMPS OVER THE LAZY DOG"));
		System.out.println("The length of the string is: " + qb.length());
		System.out.println("The string matches given pattern: "+ qb.matches("The quick brown Fox jumps over the lazy Dog"));
		System.out.println(qb.replaceAll("The", "A"));
		System.out.println(qb.substring(0,20));
		System.out.println(qb.substring(20, qb.length()));
		System.out.println(qb.substring(16,19) + "," + qb.substring(40, qb.length()));
		System.out.println(qb.toLowerCase());
		System.out.println(qb.toUpperCase());
		System.out.println("The index of a is: " + qb.indexOf('a'));
		System.out.println("The last index of e is: " + qb.lastIndexOf('e'));
		
	}
	
}
