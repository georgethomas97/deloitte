package oops;

abstract class Animal {
	int picture;
	int hunger;
	int food;
	int boundaries;
	int location;
	
	public void sleep() {
		System.out.println("Zzz...");
	}
	abstract public void eat();
	abstract public void roam();
	abstract public void makeNoise();
}

abstract class Feline extends Animal{
	public void roam() {
		System.out.println("Feline movement");
	}
}

abstract class Canine extends Animal{
	public void roam() {
		System.out.println("Canine movement");
	}
}

class Lion extends Feline{
	public void makeNoise() {
		System.out.println("Lion roars");
	}
	public void eat() {
		System.out.println("Lion eats deer");
	}
}

class Tiger extends Feline{
	public void makeNoise() {
		System.out.println("Tiger growls");
	}
	public void eat() {
		System.out.println("Tiger eats deer");
	}
}

class Cat extends Feline{
	public void makeNoise() {
		System.out.println("Cat meows");
	}
	public void eat() {
		System.out.println("Cat eats mice");
	}
}

abstract class Hippo extends Animal{
	public void makeNoise() {
		System.out.println("Hippo grunts");
	}
	public void eat() {
		System.out.println("Hippo eats grass");
	}
}

class Dog extends Canine {
	public void makeNoise() {
		System.out.println("Dog barks");
	}
	public void eat() {
		System.out.println("Dog eats meat");
	}
}

class Wolf extends Canine {
	public void makeNoise() {
		System.out.println("Wolf howls");
	}
	public void eat() {
		System.out.println("Wolf eats rabbits");
	}
}
class Hippopotamus extends Hippo {
	public void roam() {
		System.out.println("Hippopotamus moves");
	}
}

public class Animals {
	public static void main(String[] args) {
		Animal a = new Lion();
		a.eat();
		a.makeNoise();
		a.roam();
		a.sleep();
		a = new Tiger();
		a.eat();
		a.makeNoise();
		a.roam();
		a.sleep();
		a = new Cat();
		a.eat();
		a.makeNoise();
		a.roam();
		a.sleep();
		a = new Dog();
		a.eat();
		a.makeNoise();
		a.roam();
		a.sleep();
		a = new Wolf();
		a.eat();
		a.makeNoise();
		a.roam();
		a.sleep();
		a = new Hippopotamus();
		a.eat();
		a.makeNoise();
		a.roam();
		a.sleep();
		a.eat();
		a.makeNoise();
		a.roam();
		a.sleep();
		
	}
}