package oops;

public class Client {
	public static void main(String[] args) {
		Customer c1 = new Customer(100, "George");
		c1.printDetails();
		c1.setCustomerAddress("Kochi");
		c1.setBillAmount(7600);
		c1.printDetails();
	}
}
