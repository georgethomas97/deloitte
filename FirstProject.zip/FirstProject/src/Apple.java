
public class Apple {
	public void sayHi() {
		System.out.println("Hello!");
	}
}
