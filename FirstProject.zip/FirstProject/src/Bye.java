
public class Bye {
	public void sayThanks() {
		System.out.println("Thanks for visiting!");
	}
}
