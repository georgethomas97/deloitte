
import finance.Salary;
public class Welcome {

	public static void main(String[] args) {
		System.out.println("Welcome to Eclipse IDE!");
		Apple a = new Apple();
		a.sayHi();
		Ball b = new Ball();
		b.bounce();
		Cat c = new Cat();
		c.sayMeow();
		Bye y = new Bye();
		y.sayThanks();
		Salary s = new Salary();
		int res = s.calculateSalary(37500, 2500);
		System.out.println("Salary is " + res + ".");
		
	}
}
