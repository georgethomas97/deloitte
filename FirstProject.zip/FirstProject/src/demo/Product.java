package demo;

import java.util.Scanner;

public class Product {
	private int productId;
	private String productName;
	private int qoh;
	private int price;

	public Product() {
		// TODO Auto-generated constructor stub
	}

	public Product(int productId, String productName, int qoh, int price) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.qoh = qoh;
		this.price = price;
	}

	public void accept() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Product ID: ");
		productId = sc.nextInt();
		System.out.println("Product Name: ");
		productName = sc.next();
		System.out.println("QoH: ");
		qoh = sc.nextInt();
		System.out.println("Price: ");
		price = sc.nextInt();
		sc.close();
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public int getQoh() {
		return qoh;
	}

	public void setQoh(int qoh) {
		this.qoh = qoh;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return "Products [productId=" + productId + ", productName=" + productName + ", qoh=" + qoh + ", price=" + price
				+ "]";
	}

}
