package demo;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.cms.deloitte.dbcon.DBConnection;

public class ProductDisplay {
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		Connection connection = DBConnection.connect();
		Statement stmt = connection.createStatement();
		ResultSet res = stmt.executeQuery("select * from hr.product order by productid");

		while (res.next()) {
			System.out.print(res.getInt(1) + " ");
			System.out.print(res.getString(2) + " ");
			System.out.print(res.getString(3) + " ");
			System.out.println(res.getInt(4));
		}

		stmt.close();
		connection.close();
	}
}
