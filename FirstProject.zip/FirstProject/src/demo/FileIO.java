package demo;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class FileIO {
	public static void main(String[] args) throws IOException {
		File file = new File("mohan.txt");
		file.createNewFile();
		FileWriter writer = new FileWriter(file);
		writer.write("Hello I am Mohandas Karamchand Gandhi.");
		writer.close();
		FileReader reader = new FileReader(file);
		int i = 0;
		while ((i=reader.read())!=-1) {
			System.out.print((char)i);
		}
		reader.close();
	}
}
