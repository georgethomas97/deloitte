package demo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

import com.cms.deloitte.dbcon.DBConnection;

public class ProductDelete {
	public static void main(String[] args) throws SQLException {
		Connection connection = DBConnection.connect();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Product ID: ");
		int id = sc.nextInt();
		sc.close();
		Product product = new Product();
		product.setProductId(id);
		
		
		PreparedStatement statement = connection.prepareStatement("delete from hr.product where productid = ?");
		statement.setInt(1, product.getProductId());
		int rows = statement.executeUpdate();
		System.out.println(rows + " product(s) deleted.");
	}
}
