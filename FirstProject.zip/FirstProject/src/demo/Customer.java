package demo;

import java.io.Serializable;
import java.util.Scanner;

public class Customer implements Serializable, Comparable<Customer> {

	private static final long serialVersionUID = -3324031357253683742L;
	private int customerId;
	private String customerName;
	private String customerAddress;
	private transient int billAmount;
	
	public void accept() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Customer ID: ");
		customerId = sc.nextInt();
		System.out.println("Name: ");
		customerName = sc.next();
		System.out.println("Address: ");
		customerAddress = sc.next();
		System.out.println("Bill Amount: ");
		billAmount = sc.nextInt();
		sc.close();
	}
	
	public Customer() {
		// TODO Auto-generated constructor stub
	}
	public Customer(int customerID, String customerName,
			String customerAddress, int billAmount) {
		super();
		this.customerId = customerID;
		this.customerName = customerName;
		this.customerAddress = customerAddress;
		this.billAmount = billAmount;
	}
	public int getCustomerID() {
		return customerId;
	}
	public void setCustomerID(int customerID) {
		this.customerId = customerID;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getCustomerAddress() {
		return customerAddress;
	}
	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}
	public int getBillAmount() {
		return billAmount;
	}
	public void setBillAmount(int billAmount) {
		this.billAmount = billAmount;
	}
	@Override
	public String toString() {
		return "Customer [customerID=" + customerId + ", customerName="
				+ customerName + ", customerAddress=" + customerAddress
				+ ", billAmount=" + billAmount + "]";
	}
	@Override
	public int compareTo(Customer o) {
		if (this.billAmount>o.getBillAmount()) {
			return 0;
		}
		else {
			return -1;
		}
	}
}
