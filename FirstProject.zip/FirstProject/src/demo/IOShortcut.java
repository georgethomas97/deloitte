package demo;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class IOShortcut {
	public static void main(String[] args) throws IOException {
		BufferedReader bufferedReader  = new BufferedReader(new FileReader(new File("mohan.txt")));
		BufferedWriter bufferedwriter = new BufferedWriter(new FileWriter(new File("sharma.txt")));
		
		int i = 0;
		
		while ((i = bufferedReader.read())!=-1) {
			bufferedwriter.write((char)i);
		}
		bufferedReader.close();
		bufferedwriter.close();
	}
}
