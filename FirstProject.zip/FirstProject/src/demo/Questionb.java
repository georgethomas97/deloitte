package demo;
import java.util.Scanner;
public class Questionb {
	public boolean checkYear(int year) {
		if ((year%4==0 && year%100!=0) || year%400 == 0) {
			return true;
		}
		else {
			return false;
		}
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int i = sc.nextInt();
		sc.close();
		Questionb q = new Questionb();
		
		if (q.checkYear(i)) {
			System.out.println("Leap");
		}
		else {
			System.out.println("Non-leap");
		}
	}

}
