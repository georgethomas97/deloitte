package demo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.cms.deloitte.dbcon.DBConnection;

public class UpdateCustomer {
	public static void main(String[] args) throws SQLException {
		Connection connection = DBConnection.connect();
		Customer customer = new Customer();
		customer.accept();
		
		PreparedStatement statement = connection.prepareStatement("update customer set customername=?,customeraddress=?,billamount=? where customerid = ?");
		statement.setInt(4, customer.getCustomerID());
		statement.setString(1, customer.getCustomerName());
		statement.setString(2, customer.getCustomerAddress());
		statement.setInt(3, customer.getBillAmount());
		
		statement.executeUpdate();
		
		System.out.println(customer.getCustomerName() + ", your records have been updated.");
	}
}
