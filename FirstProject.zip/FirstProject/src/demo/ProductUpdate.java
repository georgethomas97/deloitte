package demo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.cms.deloitte.dbcon.DBConnection;

public class ProductUpdate {
	public static void main(String[] args) throws SQLException {
		Connection connection = DBConnection.connect();
		Product product = new Product();
		product.accept();
		
		PreparedStatement statement = connection.prepareStatement("update hr.product set productname=?,price=?,qoh=? where productid = ?");
		statement.setInt(4, product.getProductId());
		statement.setString(1, product.getProductName());
		statement.setInt(2, product.getPrice());
		statement.setInt(3, product.getQoh());
		
		statement.executeUpdate();
		
		System.out.println(product.getProductName() + " records have been updated.");
	}
}
