package demo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.cms.deloitte.dbcon.DBConnection;

public class Main {
	public static void main(String[] args) throws SQLException {
		Connection connection = DBConnection.connect();
		Customer customer = new Customer();
		customer.accept();
		
		PreparedStatement statement = connection.prepareStatement("insert into hr.customer values(?,?,?,?)");
		statement.setInt(1, customer.getCustomerID());
		statement.setString(2, customer.getCustomerName());
		statement.setString(3, customer.getCustomerAddress());
		statement.setInt(4, customer.getBillAmount());
		
		statement.executeUpdate();
		
		System.out.println(customer.getCustomerName() + ", your records have been entered.");
	}
}
