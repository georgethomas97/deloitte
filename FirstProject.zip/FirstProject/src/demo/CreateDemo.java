package demo;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import com.cms.deloitte.dbcon.DBConnection;

public class CreateDemo {
	public static void main(String[] args) throws SQLException {
		Connection conn = DBConnection.connect();
		Statement stmt = conn.createStatement();
		String query = "create table account_details(custid integer, custname varchar2(20), account_type varchar2(20), account_balance integer)";
		stmt.execute(query);
	}
}
