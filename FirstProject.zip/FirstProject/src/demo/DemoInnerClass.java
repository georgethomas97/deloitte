package demo;

interface ChangePassword {
	void change();
}
public class DemoInnerClass {
	public static void main(String[] args) {
		ChangePassword c = new ChangePassword() {
			
			@Override
			public void change() {
				System.out.println("Password changed successfully!");
			}
		};
		c.change();
	}
}
