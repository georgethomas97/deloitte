package demo;

import java.io.IOException;
import java.io.RandomAccessFile;

public class RandomDemo {
	public static void main(String[] args) throws IOException {
		RandomAccessFile file = new RandomAccessFile("friday.txt", "rw");
		file.writeUTF("Today is Friday.");
		System.out.println(file.getFilePointer());
		file.seek(0);
		String str = file.readUTF();

		System.out.println("File content is: " + str);
		
		file.seek(file.length());
		System.out.println(file.getFilePointer());

		file.writeUTF("My name is George Thomas.");
		
		file.close();
		file = new RandomAccessFile("friday.txt","rw");
		file.seek(0);
		System.out.println(file.getFilePointer());
		
		str = file.readLine();
		
		file.close();
		
		System.out.println("Updated content: " + str);
		
	}
}
