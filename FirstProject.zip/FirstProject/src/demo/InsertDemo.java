package demo;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import com.cms.deloitte.dbcon.DBConnection;

public class InsertDemo {
	public static void main(String[] args) throws SQLException {
		Connection connection = DBConnection.connect();
		Statement stmt = connection.createStatement();
		String insertQuery = "update hr.customer set customeraddress = 'Kozhikode' where customerid = 100";
		int rowsAffected = stmt.executeUpdate(insertQuery);
		System.out.println(rowsAffected + " rows affected.");
	}
}
