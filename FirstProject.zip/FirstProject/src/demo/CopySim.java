package demo;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class CopySim {
	public static void main(String[] args) throws IOException {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter file to read from: ");
		String path = sc.next();
		File file = new File(path);
		while (!file.exists()) {
			System.out.println("File " + "\"" + path + "\""
					+ " does not exist. Please enter a valid filename:");
			path = sc.next();
			file = new File(path);
		}
		FileReader reader = new FileReader(file);
		System.out
				.println("Enter file to write to (if the file is not found, it will be created) : ");
		String name = sc.next();
		sc.close();
		File write = new File(name);
		FileWriter writer = new FileWriter(write);
		int i = 0;
		while ((i = reader.read()) != -1) {
			writer.write((char) i);
		}
		reader.close();
		writer.close();
		System.out.println("File has been copied. File name: " + name);
	}
}
