package demo;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.cms.deloitte.dbcon.DBConnection;

public class AdvancedDemo {
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		Connection connection = DBConnection.connect();
		Statement stmt = connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
		ResultSet res = stmt.executeQuery("select hr.customer.* from hr.customer");
		System.out.println("Before: ");
		while (res.next()) {
			System.out.print(res.getInt(1) + " ");
			System.out.print(res.getString(2) + " ");
			System.out.print(res.getString(3) + " ");
			System.out.println(res.getInt(4));
		}

		res.moveToInsertRow();
		res.updateInt("customerid", 3);
		res.updateString("customername", "Geeta");
		res.updateString("customeraddress", "Patna");
		res.updateInt("billamount", 30000);
		res.insertRow();
		
		
		res.absolute(2);
		res.updateString(2, "Sita");
		res.updateRow();
		
		res.beforeFirst();
		
		System.out.println("After: ");
		while (res.next()) {
			System.out.print(res.getInt(1) + " ");
			System.out.print(res.getString(2) + " ");
			System.out.print(res.getString(3) + " ");
			System.out.println(res.getInt(4));
		}
		
		stmt.close();
		connection.close();
	}
}
