
public class Ball {
	public void bounce() {
		System.out.println("Ball is bouncing.");
	}

}
