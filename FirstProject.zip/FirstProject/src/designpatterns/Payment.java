package designpatterns;

public class Payment {
	private Payment() {
		System.out.println("Memory Allocated.");
	}
	private static Payment payment = new Payment();
	
	public static Payment getPaymentObject() {
		return payment;
	}
	
	public void pay(int amount) {
		System.out.println("Payment done for INR " + amount);
	}
}
