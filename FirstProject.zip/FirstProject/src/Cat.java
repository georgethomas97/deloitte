
public class Cat {
	public void sayMeow() {
		System.out.println("Meow!");
	}
}
