package com.shopping.deloitte.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class AuthenticateServlet
 */
public class AuthenticateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public AuthenticateServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		String username = request.getParameter("username");
		String password = request.getParameter("password");

//		HttpSession session = request.getSession();
//		session.setAttribute("currentBuyer", username);

		PrintWriter out = response.getWriter();
		out.println("<h3>Authenticated.</h3>");
		Cookie allCookies[] = request.getCookies();
		boolean visited = false;
		if (allCookies != null) {
			for (Cookie c : allCookies) {
				if (c.getName().equals(username)) {
					visited = true;
				}
			}
			out.println("<h1>Admin Page</h1>");
			if (visited) {
				out.println("Already visited");
			} else {
				out.println("First visit");
				Cookie cookie = new Cookie(username,username);
				response.addCookie(cookie);
			}
			out.println("<h1><form action = AdminServlet>");
			out.println("<h1>Wife Name: <input type = 'text' name = WifeName");
			out.println("<h1><input type = 'hidden' name = 'username' value =" + username + ">");
			out.println("<h1><input type = 'submit' value = 'Enter'>");
			out.println("<h1></form>");
			
		}
//		RequestDispatcher dispatcher = request.getRequestDispatcher("AdminServlet");
//		dispatcher.include(request, response);

	}
}
